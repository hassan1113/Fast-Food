// Custom Script

$(document).ready(function(){
    // Owl Carousel
    $("#banner-slider .owl-carousel").owlCarousel({
        items: 1,
        loop: true,
        autoplay: true,
        nav: true,
    });

});